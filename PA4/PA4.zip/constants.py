ROOT_STATS_DIR = './experiment_data'

# Put your other constants here.
