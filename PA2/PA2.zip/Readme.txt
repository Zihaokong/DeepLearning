How to run code: 
run main with all package installed